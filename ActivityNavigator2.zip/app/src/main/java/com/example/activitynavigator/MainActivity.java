package com.example.activitynavigator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_THIRD = 101;
    private Button btnToSecond;
    private Button btnStartForResult;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        btnToSecond = findViewById(R.id.btnToSecond);
        btnStartForResult = findViewById(R.id.btnStartForResult);
        tvResult = findViewById(R.id.tvResult);
    }

    private void setupClickListeners() {
        // 跳转到 SecondActivity
        btnToSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });

        // 启动带结果的跳转 - 点击监听器
        btnStartForResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
                startActivityForResult(intent, REQUEST_CODE_THIRD);
            }
        });

        // 启动带结果的跳转 - 长按监听器（加分项）
        btnStartForResult.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(MainActivity.this, "长按启动了带返回结果的跳转！", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
                startActivityForResult(intent, REQUEST_CODE_THIRD);
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_THIRD) {
            if (resultCode == RESULT_OK) {
                // 处理成功返回的结果
                String resultData = data.getStringExtra("result_data");
                if (resultData != null && !resultData.isEmpty()) {
                    tvResult.setText("返回结果: " + resultData);
                } else {
                    tvResult.setText("返回结果: 空数据");
                }
            } else if (resultCode == RESULT_CANCELED) {
                // 处理取消操作
                tvResult.setText("操作已取消");
                Toast.makeText(this, "用户取消了操作", Toast.LENGTH_SHORT).show();
            }
        }
    }
}