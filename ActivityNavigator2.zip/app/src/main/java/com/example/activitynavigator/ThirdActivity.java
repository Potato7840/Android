package com.example.activitynavigator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class ThirdActivity extends AppCompatActivity {

    private EditText etInput;
    private Button btnReturnResult;
    private Button btnReturnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        etInput = findViewById(R.id.etInput);
        btnReturnResult = findViewById(R.id.btnReturnResult);
        btnReturnCancel = findViewById(R.id.btnReturnCancel);
    }

    private void setupClickListeners() {
        // 返回结果
        btnReturnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = etInput.getText().toString().trim();
                Intent resultIntent = new Intent();
                resultIntent.putExtra("result_data", inputText);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

        // 返回取消（加分项）
        btnReturnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }
}
